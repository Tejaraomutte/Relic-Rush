import React, { useState } from 'react';
import Kriss from './kriss-kross/App';
import Magic from './magic-square/App';
import MathPuzzle from './mathpuzzle/App';
import NQueens from './n-queens/App';
import Sudoku from './sudoku/App';
import Hanoi from './towers-of-hanoi/App';
import './App.css';

function App() {
  const [game, setGame] = useState(null);

  // add a class to <body> so individual game CSS can target backgrounds
  React.useEffect(() => {
    const classPrefix = 'game-';
    // remove any previous game-* classes
    document.body.className = document.body.className
      .split(' ')
      .filter(c => !c.startsWith(classPrefix))
      .join(' ');
    if (game) {
      document.body.classList.add(`${classPrefix}${game}`);
    }
  }, [game]);

  const renderGame = () => {
    switch (game) {
      case 'kriss': return <Kriss />;
      case 'magic': return <Magic />;
      case 'math': return <MathPuzzle />;
      case 'nqueens': return <NQueens />;
      case 'sudoku': return <Sudoku />;
      case 'hanoi': return <Hanoi />;
      default: return null;
    }
  };

  return (
    <div className="root-container">
      <header>
        <h1>Round 2 Games</h1>
      </header>
      {!game && (
        <nav className="menu">
          <button onClick={() => setGame('kriss')}>Kriss-Kross</button>
          <button onClick={() => setGame('magic')}>Magic Square</button>
          <button onClick={() => setGame('math')}>Math Puzzle</button>
          <button onClick={() => setGame('nqueens')}>N-Queens</button>
          <button onClick={() => setGame('sudoku')}>Sudoku</button>
          <button onClick={() => setGame('hanoi')}>Towers of Hanoi</button>
        </nav>
      )}
      {game && (
        <div className="game-area">
          <button className="back-btn" onClick={() => setGame(null)}>&larr; Back to menu</button>
          {renderGame()}
        </div>
      )}
    </div>
  );
}

export default App;
